package com.founder.bt.webapp.action;

import java.io.File;
import java.io.InputStream;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts2.ServletActionContext;

import com.founder.bt.consts.ConstantsBT;
import com.founder.bt.dao.AppArchtypecategoryintemplateDao;
import com.founder.bt.dao.AppAssetbasicinfoDao;
import com.founder.bt.dao.AppAssetfilesDao;
import com.founder.bt.dao.AppDglcollectionDao;
import com.founder.bt.dao.AppFondsdescDao;
import com.founder.bt.dao.SysArchtypeDao;
import com.founder.bt.dao.SysAssetcategoryDao;
import com.founder.bt.dao.SysAssetschemeDao;
import com.founder.bt.dao.SysAttrtransmitDao;
import com.founder.bt.entity.AppArchtypecategoryintemplate;
import com.founder.bt.entity.AppDglcollection;
import com.founder.bt.entity.AppFondsdesc;
import com.founder.bt.entity.SysArchtype;
import com.founder.bt.entity.SysAssetcategory;
import com.founder.bt.entity.SysAssetscheme;
import com.founder.bt.utils.POIExcelUtil;
import com.founder.zt.database.Database;
import com.founder.zt.listview.pojo.ColumnViewTo;
import com.founder.zt.pojo.InvokeResult;
import com.founder.zt.pojo.TreeNode;
import com.founder.zt.utils.JsonUtil;
import com.founder.zt.utils.LogUtil;
import com.founder.zt.utils.ZTUtil;
import com.opensymphony.xwork2.Action;

/**
 * 日期审核字段
 * 
 * @author cuijie
 * 
 */
public class PreGuiDangAction extends AbstractBTBaseAction {
	private long archTypeId;
	private long categoryId;
	private long assetId;
	private long permissionId;
	private String archTypesJson;
	private String operName;
	private long newCategoryId;

	public String execute() throws Exception {
		long appID = ZTUtil.getZtAppId();
		boolean isadmin = ZTUtil.isAdmin(this.getLoginName());
		this.setOperName("preGuidang");
		SysArchtypeDao archtypedao = new SysArchtypeDao();
		List<SysArchtype> sysArchtypes = archtypedao
				.getAllSysArchtypeBySql("select * from SYS_ARCHTYPE where FATHERID = 0 order by SORTORDER");
		archTypesJson = JsonUtil.toJson(sysArchtypes);

		AppFondsdescDao fondsdao = new AppFondsdescDao();
		List<AppFondsdesc> fondses = fondsdao.getAppFondsdescsExt();
		for (int i = 0; i < fondses.size(); i++) {
			AppFondsdesc fonds = fondses.get(i);
			fonds.setFondsname(fonds.getFondsno() + "|" + fonds.getFondsname());
			if (fonds.getStopFlag().equals("1")) {
				fonds.setFondsname(fonds.getFondsno() + "|" + fonds.getFondsname() + "(已停用)");
			}
		}
		return Action.SUCCESS;
	}

	public String getArchTypeTree() throws Exception {
		String jsonStr = "";
		try {
			SysArchtypeDao archtypedao = new SysArchtypeDao();
			SysAssetcategoryDao categorydao = new SysAssetcategoryDao();

			SysArchtype sysArchtype = archtypedao.getSysArchtype(archTypeId);
			List<TreeNode> tree = new ArrayList<TreeNode>();
			if (archTypeId > 0) {
				List<SysArchtype> archtypes = archtypedao
						.getAllSysArchtypeByWhere("FATHERID=" + archTypeId + " order by SORTORDER");
				for (int i = 0; i < archtypes.size(); i++) {
					SysArchtype archtype = archtypes.get(i);
					TreeNode branch = new TreeNode(Long.toString(archtype.getId()),
							archtype.getName() + "(" + archtype.getCode() + ")", "closed");
					tree.add(branch);
				}
				String sql = "";
				sql += "select a.*";
				sql += "  from SYS_ASSETCATEGORY a";
				sql += " inner join SYS_ARCHTYPEINCLUDE b";
				sql += "    on a.ID = b.CATEGORYID";
				sql += "   where ARCHTYPEID = " + archTypeId + " order by b.SORTORDER";
				List<SysAssetcategory> categorys = categorydao.getAllSysAssetcategoryBySql(sql);

				for (int i = 0; i < categorys.size(); i++) {
					SysAssetcategory category = categorys.get(i);
					long categoryId = category.getId();
					long categoryType = category.getCategorytype();
					String categoryName = category.getName();
					TreeNode branchCategory = new TreeNode(Long.toString(categoryId),
							sysArchtype.getCode() + " - " + categoryName, "open");
					branchCategory.getAttributes().put("categoryId", categoryId);
					branchCategory.getAttributes().put("categoryType", categoryType);
					tree.add(branchCategory);
				}
			}
			jsonStr = JsonUtil.toJson(tree);
		} catch (Exception e) {
			e.printStackTrace();
			LogUtil.getOnlineLog(this.getClass()).error(e, e.getMessage());
			throw e;
		}
		this.getResponse().setContentType("text/html;charset=UTF-8");
		this.getRequest().setCharacterEncoding("UTF-8");
		this.getResponse().setHeader("Cache-Control", "no-cache");
		getResponse().getWriter().println(jsonStr);
		getResponse().getWriter().close();
		return Action.NONE;
	}

	public String save() throws Exception {
		InvokeResult invokeResult = new InvokeResult();
		try {
			AppAssetbasicinfoDao basicinfodao = new AppAssetbasicinfoDao();
			SysAttrtransmitDao attrtransmitdao = new SysAttrtransmitDao();
			Map<String, String> attrnamemap = attrtransmitdao.getAttributenameMap(categoryId, newCategoryId);
			List<Map> oldassets = basicinfodao
					.selectSql("select * from APP_ASSETCUSTOMINFO" + categoryId + " where ID=" + assetId);
			for (Map oldasset : oldassets) {
				Map newasset = new HashMap();
				Iterator<String> it = attrnamemap.keySet().iterator();
				while(it.hasNext()){
					String mattrname = it.next();
					String sattrname = attrnamemap.get(mattrname);
					if(oldasset.get(mattrname) != null){
						newasset.put(sattrname, oldasset.get(mattrname));
					}
				}
				newasset.put("ID", null);
				newasset.put("STATUSBT", ConstantsBT.SYSTEM_STATUS_RECEIVE);
				long newAssetId=basicinfodao.add(newCategoryId, newasset);
				AppAssetfilesDao appAssetfilesDao = new AppAssetfilesDao();
				appAssetfilesDao.updateSql("update from APP_ASSETFILES set assetid="+newAssetId+"where assetid="+assetId);
				basicinfodao.updateSql("delete APP_ASSETCUSTOMINFO" +categoryId+ " where ID=" + assetId);
			}
			invokeResult.setResult(true);
			invokeResult.setSuccessMessage("保存成功");
		} catch (Exception e) {
			e.printStackTrace();
			invokeResult.setResult(false);
			invokeResult.setErrorMessage("保存失败[" + e.getMessage() + "]");
		}

		String jsonStr = JsonUtil.toJson(invokeResult);
		this.getResponse().setContentType("text/html;charset=UTF-8");
		this.getRequest().setCharacterEncoding("UTF-8");
		this.getResponse().setHeader("Cache-Control", "no-cache");
		getResponse().getWriter().println(jsonStr);
		getResponse().getWriter().close();
		return Action.NONE;
	}

	public long getArchTypeId() {
		return archTypeId;
	}

	public void setArchTypeId(long archTypeId) {
		this.archTypeId = archTypeId;
	}

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(long permissionId) {
		this.permissionId = permissionId;
	}

	public String getArchTypesJson() {
		return archTypesJson;
	}

	public void setArchTypesJson(String archTypesJson) {
		this.archTypesJson = archTypesJson;
	}

	public String getOperName() {
		return operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}

	public long getAssetId() {
		return assetId;
	}

	public void setAssetId(long assetId) {
		this.assetId = assetId;
	}

	public long getNewCategoryId() {
		return newCategoryId;
	}

	public void setNewCategoryId(long newCategoryId) {
		this.newCategoryId = newCategoryId;
	}

}
